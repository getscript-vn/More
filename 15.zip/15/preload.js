const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('api', {
    min: () => ipcRenderer.send('app:min'),
    max: () => ipcRenderer.send('app:max'),
    close: () => ipcRenderer.send('app:close'),
    hide: () => ipcRenderer.send('app:hide'),
    
    checkApi: (u) => ipcRenderer.invoke('check-api', u),
    openChrome: (c) => ipcRenderer.invoke('open-chrome', c),
    getHistory: () => ipcRenderer.invoke('get-history'),
    getStatus: () => ipcRenderer.invoke('get-status'),
    stopChrome: (p) => ipcRenderer.invoke('stop-chrome', p),
    clearProfiles: () => ipcRenderer.invoke('clear-profiles') // NEW
});